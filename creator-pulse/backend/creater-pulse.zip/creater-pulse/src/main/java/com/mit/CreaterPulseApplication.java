package com.mit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreaterPulseApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreaterPulseApplication.class, args);
	}

}
